﻿# Tico Trip – kis webszerver a laptopra (semmit nem kell telepíteni)
# A játék mappáját kiszolgálja a helyi wifin, hogy a telefonok elérjék.
$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
$Host.UI.RawUI.WindowTitle = 'Tico Trip szerver'
$root = [IO.Path]::GetFullPath((Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'jatek'))
if (-not (Test-Path (Join-Path $root 'index.html'))) { Write-Host "Nem találom a jatek mappát: $root" -ForegroundColor Red; exit 1 }

# szabad port keresése (8080-tól)
$listener = $null; $port = 0
foreach ($p in 8080..8099) { try { $l = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Any, $p); $l.Start(); $listener = $l; $port = $p; break } catch {} }
if (-not $listener) { Write-Host 'Nem sikerült portot nyitni (8080-8099 mind foglalt).' -ForegroundColor Red; exit 1 }

# a laptop címe(i) a helyi hálózaton
$ips = @()
foreach ($ni in [Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces()) {
  if ($ni.OperationalStatus -ne 'Up' -or $ni.NetworkInterfaceType -eq 'Loopback' -or $ni.Description -match 'Virtual|VMware|Hyper-V|VirtualBox|Bluetooth') { continue }
  foreach ($a in $ni.GetIPProperties().UnicastAddresses) { $ip = $a.Address.ToString(); if ($a.Address.AddressFamily -eq 'InterNetwork' -and -not $ip.StartsWith('169.254')) { $ips += $ip } }
}

Clear-Host
Write-Host ''
Write-Host '   TICO TRIP – a szerver fut!' -ForegroundColor Yellow
Write-Host ''
Write-Host '   Írd be a telefonokon a Safariba (ugyanazon a wifin):' -ForegroundColor White
foreach ($ip in $ips) { Write-Host ("      http://{0}:{1}" -f $ip, $port) -ForegroundColor Green }
if ($ips.Count -eq 0) { Write-Host '      (nem találtam wifi-címet – csatlakozik a laptop a wifihez?)' -ForegroundColor Red }
Write-Host ''
Write-Host '   Tipp: Safari → Megosztás → "Főképernyőhöz adás" = saját ikon, teljes képernyő.' -ForegroundColor Gray
Write-Host '   Ha a Windows tűzfal rákérdez: "Magánhálózat" → Engedélyezés.' -ForegroundColor Gray
Write-Host '   A játék addig megy, amíg ez az ablak nyitva van. Leállítás: zárd be az ablakot.' -ForegroundColor Gray
Write-Host ''

$types = @{ '.html'='text/html; charset=utf-8'; '.js'='text/javascript; charset=utf-8'; '.mjs'='text/javascript; charset=utf-8'; '.json'='application/json'; '.webmanifest'='application/manifest+json'; '.png'='image/png'; '.jpg'='image/jpeg'; '.svg'='image/svg+xml'; '.css'='text/css'; '.ico'='image/x-icon'; '.txt'='text/plain; charset=utf-8' }
$enc = [Text.Encoding]::ASCII
while ($true) {
  $c = $listener.AcceptTcpClient()
  try {
    $c.ReceiveTimeout = 4000; $c.SendTimeout = 15000
    $s = $c.GetStream()
    $r = New-Object IO.StreamReader($s, $enc, $false, 4096, $true)
    $line = $r.ReadLine(); if (-not $line) { continue }
    while ($true) { $h = $r.ReadLine(); if ($h -eq $null -or $h -eq '') { break } }
    $parts = $line.Split(' '); $method = $parts[0]; $path = [Uri]::UnescapeDataString(($parts[1] -split '\?')[0])
    if ($path -eq '/' -or $path -eq '') { $path = '/index.html' }
    $full = [IO.Path]::GetFullPath((Join-Path $root ($path.TrimStart('/').Replace('/', [IO.Path]::DirectorySeparatorChar))))
    if (-not $full.StartsWith($root, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $full -PathType Leaf)) {
      $body = $enc.GetBytes('404 - nincs ilyen fájl'); $hd = "HTTP/1.1 404 Not Found`r`nContent-Type: text/plain`r`nContent-Length: $($body.Length)`r`nConnection: close`r`n`r`n"
    } else {
      $body = [IO.File]::ReadAllBytes($full); $ext = [IO.Path]::GetExtension($full).ToLower(); $t = $types[$ext]; if (-not $t) { $t = 'application/octet-stream' }
      $hd = "HTTP/1.1 200 OK`r`nContent-Type: $t`r`nContent-Length: $($body.Length)`r`nCache-Control: no-cache`r`nConnection: close`r`n`r`n"
    }
    $hb = $enc.GetBytes($hd); $s.Write($hb, 0, $hb.Length); if ($method -ne 'HEAD') { $s.Write($body, 0, $body.Length) }; $s.Flush()
  } catch { } finally { $c.Close() }
}
