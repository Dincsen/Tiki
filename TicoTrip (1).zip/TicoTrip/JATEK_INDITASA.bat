@echo off
chcp 65001 >nul
title Tico Trip szerver
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0szerver.ps1"
echo.
echo A szerver leallt. Nyomj meg egy gombot a bezarashoz.
pause >nul
