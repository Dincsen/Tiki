// Tico Trip service worker: a játék és a könyvtárak gyorsítótárazása (gyorsabb indulás, gyenge netnél is)
const CACHE = 'ticotrip-v16';
const CORE = ['./', './index.html', './manifest.webmanifest', './icon-180.png', './icon-192.png', './icon-512.png'];
const LIBS = ['./lib/three.module.js', './lib/jsm/utils/BufferGeometryUtils.js', './lib/cannon-es.js', './lib/peerjs.min.js'];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE).then(() => c.addAll(LIBS).catch(() => { }))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request; if (req.method !== 'GET') return;
  const url = new URL(req.url);
  // a hálózati kapcsolódás (PeerJS szerver) sosem a gyorsítótárból megy
  if (url.hostname.includes('peerjs.com')) return;
  const isLib = LIBS.some(u => req.url.endsWith(u.slice(1)));
  const isPage = url.origin === location.origin && (req.mode === 'navigate' || url.pathname.endsWith('.html') || url.pathname.endsWith('/'));
  if (isPage) { // oldal: előbb hálózat (hogy a frissítés megérkezzen), ha nincs net, gyorsítótár
    e.respondWith(fetch(req).then(r => { const cp = r.clone(); caches.open(CACHE).then(c => c.put(req, cp)); return r; }).catch(() => caches.match(req).then(r => r || caches.match('./index.html'))));
    return;
  }
  if (isLib || url.origin === location.origin) {
    e.respondWith(caches.match(req).then(r => r || fetch(req).then(res => { if (res.ok) { const cp = res.clone(); caches.open(CACHE).then(c => c.put(req, cp)); } return res; })));
  }
});
